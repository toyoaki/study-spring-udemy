package com.study.spring.udemy.lab4noun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab4NounApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab4NounApplication.class, args);
	}
}
