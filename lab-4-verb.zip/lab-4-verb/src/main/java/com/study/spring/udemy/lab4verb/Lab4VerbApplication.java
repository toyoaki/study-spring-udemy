package com.study.spring.udemy.lab4verb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab4VerbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab4VerbApplication.class, args);
	}
}
